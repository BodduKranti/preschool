import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-timeline1',
  templateUrl: './timeline1.component.html',
  styleUrls: ['./timeline1.component.scss']
})
export class Timeline1Component implements OnInit {
  constructor() {}
  ngOnInit() {}
}
