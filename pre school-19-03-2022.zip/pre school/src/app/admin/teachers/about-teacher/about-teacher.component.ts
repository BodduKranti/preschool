import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-teacher',
  templateUrl: './about-teacher.component.html',
  styleUrls: ['./about-teacher.component.sass']
})
export class AboutTeacherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
