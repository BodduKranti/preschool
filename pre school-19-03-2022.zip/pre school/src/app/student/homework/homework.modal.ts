export class Homework {
  id: string;
  class: string;
  section: string;
  subject: string;
  homeworkDate: string;
  submissionDate: string;
  evalutionDate: string;
  status: string;
}
